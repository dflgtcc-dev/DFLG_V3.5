<?php

namespace app\services;

class CalculadoraService
{
    private const LIMITE_MESES = 1200; // 100 anos

    private array $erros = [];

    public function getCalculadoras(): array
    {
        return [
            'juros-compostos' => [
                'nome' => 'Juros compostos com aportes',
                'descricao' => 'Veja quanto seu dinheiro rende com um valor inicial e aportes mensais.',
                'icone' => 'bi-graph-up-arrow',
            ],
            'aporte-meta' => [
                'nome' => 'Aporte para atingir uma meta',
                'descricao' => 'Descubra quanto guardar por mês para chegar ao valor que você quer.',
                'icone' => 'bi-bullseye',
            ],
            'tempo-meta' => [
                'nome' => 'Tempo para atingir uma meta',
                'descricao' => 'Descubra em quanto tempo você chega ao valor que quer com seus aportes.',
                'icone' => 'bi-hourglass-split',
            ],
            'independencia-financeira' => [
                'nome' => 'Independência financeira',
                'descricao' => 'Descubra quanto patrimônio você precisa para viver de renda e em quanto tempo chega lá.',
                'icone' => 'bi-piggy-bank',
            ],
            'aposentadoria' => [
                'nome' => 'Planejamento de aposentadoria',
                'descricao' => 'Veja o patrimônio e a renda mensal que você pode ter ao se aposentar.',
                'icone' => 'bi-sunset',
            ],
            'reserva-emergencia' => [
                'nome' => 'Reserva de emergência',
                'descricao' => 'Calcule o valor da sua reserva e em quanto tempo você consegue montá-la.',
                'icone' => 'bi-shield-check',
            ],
        ];
    }

    public function calcularJurosCompostos(array $dados): array|false
    {
        $this->erros = [];

        $valorInicial = $this->valor($dados, 'valorInicial', 'Informe um valor inicial válido.');
        $aporteMensal = $this->valor($dados, 'aporteMensal', 'Informe um aporte mensal válido.');
        $taxaMensal = $this->taxaMensal($dados);
        $prazoMeses = $this->prazoMeses($dados);

        if (!empty($this->erros)) {
            return false;
        }

        $montanteFinal = $this->montante($valorInicial, $aporteMensal, $taxaMensal, $prazoMeses);

        if (!is_finite($montanteFinal)) {
            $this->erros['geral'] = 'Os valores informados geram um resultado grande demais.';

            return false;
        }

        $totalInvestido = $valorInicial + ($aporteMensal * $prazoMeses);

        return array_merge($this->resumoTaxa($taxaMensal), [
            'totalInvestido' => $totalInvestido,
            'rendimento' => $montanteFinal - $totalInvestido,
            'montanteFinal' => $montanteFinal,
        ]);
    }

    public function calcularAporteMeta(array $dados): array|false
    {
        $this->erros = [];

        $valorAlvo = $this->valor($dados, 'valorAlvo', 'Informe um valor alvo maior que zero.', true);
        $valorInicial = $this->valor($dados, 'valorInicial', 'Informe um valor inicial válido.');
        $taxaMensal = $this->taxaMensal($dados);
        $prazoMeses = $this->prazoMeses($dados);

        if (!empty($this->erros)) {
            return false;
        }

        $fator = pow(1 + $taxaMensal, $prazoMeses);
        $falta = $valorAlvo - ($valorInicial * $fator);

        if ($falta <= 0) {
            // o valor inicial sozinho já chega na meta
            $aporteMensal = 0.0;
        } else {
            $aporteMensal = $taxaMensal > 0
                ? $falta * $taxaMensal / ($fator - 1)
                : $falta / $prazoMeses;
        }

        $montanteFinal = $this->montante($valorInicial, $aporteMensal, $taxaMensal, $prazoMeses);

        if (!is_finite($montanteFinal)) {
            $this->erros['geral'] = 'Os valores informados geram um resultado grande demais.';

            return false;
        }

        $totalInvestido = $valorInicial + ($aporteMensal * $prazoMeses);

        return array_merge($this->resumoTaxa($taxaMensal), [
            'aporteMensal' => $aporteMensal,
            'metaJaAtingida' => $falta <= 0,
            'totalInvestido' => $totalInvestido,
            'rendimento' => $montanteFinal - $totalInvestido,
            'montanteFinal' => $montanteFinal,
        ]);
    }

    public function calcularTempoMeta(array $dados): array|false
    {
        $this->erros = [];

        $valorAlvo = $this->valor($dados, 'valorAlvo', 'Informe um valor alvo maior que zero.', true);
        $valorInicial = $this->valor($dados, 'valorInicial', 'Informe um valor inicial válido.');
        $aporteMensal = $this->valor($dados, 'aporteMensal', 'Informe um aporte mensal válido.');
        $taxaMensal = $this->taxaMensal($dados);

        if (!empty($this->erros)) {
            return false;
        }

        $meses = $this->mesesParaMeta($valorAlvo, $valorInicial, $aporteMensal, $taxaMensal);

        if ($meses === null) {
            return false;
        }

        $montanteFinal = $this->montante($valorInicial, $aporteMensal, $taxaMensal, $meses);
        $totalInvestido = $valorInicial + ($aporteMensal * $meses);

        return array_merge($this->resumoTaxa($taxaMensal), [
            'meses' => $meses,
            'anos' => intdiv($meses, 12),
            'mesesRestantes' => $meses % 12,
            'metaJaAtingida' => $meses === 0,
            'totalInvestido' => $totalInvestido,
            'rendimento' => $montanteFinal - $totalInvestido,
            'montanteFinal' => $montanteFinal,
        ]);
    }

    public function calcularIndependenciaFinanceira(array $dados): array|false
    {
        $this->erros = [];

        $rendaMensal = $this->valor($dados, 'rendaMensal', 'Informe uma renda mensal maior que zero.', true);
        $patrimonioAtual = $this->valor($dados, 'patrimonioAtual', 'Informe um patrimônio atual válido.');
        $aporteMensal = $this->valor($dados, 'aporteMensal', 'Informe um aporte mensal válido.');
        $taxaMensal = $this->taxaMensal($dados);

        if ($taxaMensal === 0.0) {
            $this->erros['taxa'] = 'Informe uma taxa maior que zero.';
        }

        if (!empty($this->erros)) {
            return false;
        }

        // patrimônio que, rendendo a taxa informada, gera a renda mensal sem gastar o principal
        $patrimonioNecessario = $rendaMensal / $taxaMensal;

        $meses = $this->mesesParaMeta($patrimonioNecessario, $patrimonioAtual, $aporteMensal, $taxaMensal);

        if ($meses === null) {
            return false;
        }

        $montanteFinal = $this->montante($patrimonioAtual, $aporteMensal, $taxaMensal, $meses);
        $totalInvestido = $patrimonioAtual + ($aporteMensal * $meses);

        return array_merge($this->resumoTaxa($taxaMensal), [
            'patrimonioNecessario' => $patrimonioNecessario,
            'falta' => max(0, $patrimonioNecessario - $patrimonioAtual),
            'meses' => $meses,
            'anos' => intdiv($meses, 12),
            'mesesRestantes' => $meses % 12,
            'metaJaAtingida' => $meses === 0,
            'totalInvestido' => $totalInvestido,
            'rendimento' => $montanteFinal - $totalInvestido,
            'montanteFinal' => $montanteFinal,
        ]);
    }

    public function calcularAposentadoria(array $dados): array|false
    {
        $this->erros = [];

        $idadeAtual = $this->inteiro($dados, 'idadeAtual', 'Informe uma idade atual válida.');
        $idadeAposentadoria = $this->inteiro($dados, 'idadeAposentadoria', 'Informe uma idade de aposentadoria válida.');
        $patrimonioAtual = $this->valor($dados, 'patrimonioAtual', 'Informe um patrimônio atual válido.');
        $aporteMensal = $this->valor($dados, 'aporteMensal', 'Informe um aporte mensal válido.');
        $taxaMensal = $this->taxaMensal($dados);

        if ($idadeAtual !== null && $idadeAposentadoria !== null) {
            if ($idadeAposentadoria <= $idadeAtual) {
                $this->erros['idadeAposentadoria'] = 'A idade de aposentadoria deve ser maior que a idade atual.';
            } elseif (($idadeAposentadoria - $idadeAtual) * 12 > self::LIMITE_MESES) {
                $this->erros['idadeAposentadoria'] = 'O prazo até a aposentadoria deve ser de no máximo 100 anos.';
            }
        }

        if (!empty($this->erros)) {
            return false;
        }

        $anos = $idadeAposentadoria - $idadeAtual;
        $meses = $anos * 12;

        $montanteFinal = $this->montante($patrimonioAtual, $aporteMensal, $taxaMensal, $meses);

        if (!is_finite($montanteFinal)) {
            $this->erros['geral'] = 'Os valores informados geram um resultado grande demais.';

            return false;
        }

        $totalInvestido = $patrimonioAtual + ($aporteMensal * $meses);

        return array_merge($this->resumoTaxa($taxaMensal), [
            'anos' => $anos,
            'totalInvestido' => $totalInvestido,
            'rendimento' => $montanteFinal - $totalInvestido,
            'montanteFinal' => $montanteFinal,
            // estimativa: o patrimônio rendendo a taxa informada, sem gastar o principal
            'rendaMensal' => $montanteFinal * $taxaMensal,
        ]);
    }

    public function calcularReservaEmergencia(array $dados): array|false
    {
        $this->erros = [];

        $gastoMensal = $this->valor($dados, 'gastoMensal', 'Informe um gasto mensal maior que zero.', true);
        $mesesCobertura = $this->inteiro($dados, 'mesesCobertura', 'Informe os meses de cobertura (1 ou mais).', 1);
        $valorGuardado = $this->valor($dados, 'valorGuardado', 'Informe um valor guardado válido.');
        $aporteMensal = $this->valor($dados, 'aporteMensal', 'Informe um aporte mensal válido.');
        $taxaMensal = $this->taxaMensal($dados);

        if (!empty($this->erros)) {
            return false;
        }

        $valorReserva = $gastoMensal * $mesesCobertura;

        $meses = $this->mesesParaMeta($valorReserva, $valorGuardado, $aporteMensal, $taxaMensal);

        if ($meses === null) {
            return false;
        }

        $montanteFinal = $this->montante($valorGuardado, $aporteMensal, $taxaMensal, $meses);
        $totalInvestido = $valorGuardado + ($aporteMensal * $meses);

        return array_merge($this->resumoTaxa($taxaMensal), [
            'valorReserva' => $valorReserva,
            'falta' => max(0, $valorReserva - $valorGuardado),
            'meses' => $meses,
            'anos' => intdiv($meses, 12),
            'mesesRestantes' => $meses % 12,
            'metaJaAtingida' => $meses === 0,
            'totalInvestido' => $totalInvestido,
            'rendimento' => $montanteFinal - $totalInvestido,
            'montanteFinal' => $montanteFinal,
        ]);
    }

    public function getErros(): array
    {
        return $this->erros;
    }

    // valor final com aportes no fim de cada mês: V0 x (1+i)^n + A x ((1+i)^n - 1) / i
    private function montante(float $valorInicial, float $aporteMensal, float $taxaMensal, int $meses): float
    {
        $fator = pow(1 + $taxaMensal, $meses);

        $montanteAportes = $taxaMensal > 0
            ? $aporteMensal * (($fator - 1) / $taxaMensal)
            : $aporteMensal * $meses;

        return ($valorInicial * $fator) + $montanteAportes;
    }

    // meses para o valor inicial, com aportes no fim de cada mês, chegar ao valor alvo;
    // devolve 0 se o valor inicial já chega lá e null (com o erro preenchido) se não chega em até 100 anos
    private function mesesParaMeta(float $valorAlvo, float $valorInicial, float $aporteMensal, float $taxaMensal): ?int
    {
        if ($valorInicial >= $valorAlvo) {
            return 0;
        }

        if ($aporteMensal == 0 && ($taxaMensal == 0 || $valorInicial == 0)) {
            $this->erros['aporteMensal'] = 'Com esses valores a meta nunca é atingida. Informe um aporte mensal ou um valor inicial com taxa maior que zero.';

            return null;
        }

        if ($taxaMensal > 0) {
            $base = $aporteMensal / $taxaMensal;
            $meses = log(($valorAlvo + $base) / ($valorInicial + $base)) / log(1 + $taxaMensal);
        } else {
            $meses = ($valorAlvo - $valorInicial) / $aporteMensal;
        }

        if ($meses > self::LIMITE_MESES) {
            $this->erros['geral'] = 'Com esses valores a meta levaria mais de 100 anos. Ajuste os dados.';

            return null;
        }

        // a fórmula devolve o prazo fracionado: arredonda para cima e confere mês a mês,
        // para o erro de arredondamento do ponto flutuante não mudar o resultado
        $meses = max(1, (int) ceil($meses - 1e-9));

        while ($this->montante($valorInicial, $aporteMensal, $taxaMensal, $meses) < $valorAlvo - 1e-6) {
            $meses++;
        }

        while ($meses > 1 && $this->montante($valorInicial, $aporteMensal, $taxaMensal, $meses - 1) >= $valorAlvo - 1e-6) {
            $meses--;
        }

        return $meses;
    }

    private function inteiro(array $dados, string $campo, string $mensagem, int $minimo = 0): ?int
    {
        $inteiro = filter_var($dados[$campo] ?? '', FILTER_VALIDATE_INT);

        if ($inteiro === false || $inteiro < $minimo) {
            $this->erros[$campo] = $mensagem;

            return null;
        }

        return $inteiro;
    }

    // lê a taxa e a unidade (mensal ou anual) e devolve a taxa mensal em decimal (1% = 0.01)
    private function taxaMensal(array $dados): ?float
    {
        $taxa = $this->numero($dados['taxa'] ?? '');
        $unidade = $dados['unidadeTaxa'] ?? '';

        if ($taxa === null || $taxa < 0) {
            $this->erros['taxa'] = 'Informe uma taxa válida.';

            return null;
        }

        if (!in_array($unidade, ['mensal', 'anual'])) {
            $this->erros['unidadeTaxa'] = 'Selecione se a taxa é mensal ou anual.';

            return null;
        }

        // a taxa anual vira mensal pela equivalência composta
        return $unidade === 'anual' ? pow(1 + ($taxa / 100), 1 / 12) - 1 : $taxa / 100;
    }

    private function prazoMeses(array $dados): ?int
    {
        $prazoMeses = filter_var($dados['prazoMeses'] ?? '', FILTER_VALIDATE_INT);

        if ($prazoMeses === false || $prazoMeses <= 0 || $prazoMeses > self::LIMITE_MESES) {
            $this->erros['prazoMeses'] = 'O prazo deve ser de 1 a ' . self::LIMITE_MESES . ' meses.';

            return null;
        }

        return $prazoMeses;
    }

    private function valor(array $dados, string $campo, string $mensagem, bool $maiorQueZero = false): ?float
    {
        $valor = $this->numero($dados[$campo] ?? '');

        if ($valor === null || $valor < 0 || ($maiorQueZero && $valor == 0)) {
            $this->erros[$campo] = $mensagem;

            return null;
        }

        return $valor;
    }

    // a mesma taxa nas duas unidades, para o usuário ver a conversão
    private function resumoTaxa(float $taxaMensal): array
    {
        return [
            'taxaMensal' => $taxaMensal * 100,
            'taxaAnual' => (pow(1 + $taxaMensal, 12) - 1) * 100,
        ];
    }

    private function numero(mixed $valor): ?float
    {
        if ($valor === '' || !is_numeric($valor)) {
            return null;
        }

        return (float) $valor;
    }
}